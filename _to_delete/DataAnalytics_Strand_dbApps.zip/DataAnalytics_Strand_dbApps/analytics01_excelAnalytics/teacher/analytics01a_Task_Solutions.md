# analytics01a Task — ANSWER KEY (INSTRUCTOR)

**DO NOT DISTRIBUTE TO STUDENTS**

## Part A
1. Total revenue = **$1600.00** (`=SUM(H2:H64)`)
2. Average order = **$25.40** (`=AVERAGE(H2:H64)`)
3. Largest order = **$56.00** (`=MAX(H2:H64)`) — a Large ($14) × quantity 4
4. Number of orders = **63** (`=COUNT(F2:F64)`)

## Part B
5. Highest-revenue region = **West** ($499.00). *(Region totals: West 499, East 435, South 363, North 303 = 1600.)*
6. Accept any correct single largest cross-tab cell read from the student's PivotTable (values vary by region×size; grade that they read the cross-tab correctly).

## Part C
7. Column chart present, titled, axes labeled. (5 pts)
8. Pie chart of revenue by size present. (5 pts)

## Short answer
9. A PivotTable groups rows by a category and summarizes a value for each group — exactly what `GROUP BY` does in SQL (one summary row per category).
10. **Pie chart** — it shows each size's *share of the whole* (parts of 100%). *(A bar chart compares sizes but doesn't emphasize share.)*

**Teacher note:** the four region totals must sum to $1600. If a student's PivotTable total isn't 1600, they likely filtered rows or mis-set the value field to Count instead of Sum.
