# analytics03a Task — ANSWER KEY (INSTRUCTOR)

**DO NOT DISTRIBUTE TO STUDENTS**

## Views
1. Highest region = **West** (~$499). Bars total **$1,600**.
2. Revenue by Size present (SUM Line Total per size).
3. Line chart over time present (Order Date by Week).

## Dashboard
4. Three views combined on one dashboard, titled. (10 pts)
5. A working **Region filter** that updates all views when clicked. (10 pts)

## Short answer
6. A **Dimension** is a category/qualitative field used to slice the data (region, size); a **Measure** is a
   numeric field that gets aggregated (SUM of line_total). *Dimensions ≈ GROUP BY columns; Measures ≈ the SUM.*
7. A filter lets the viewer **explore interactively** — clicking a region (or using a filter control) updates
   every view to show just that slice, without rebuilding anything.
8. Any of: **interactivity** (clickable filters), a **shareable/published** dashboard, a **live connection**
   to the SQL database, or a more polished visual for a **non-technical audience**.

**Teacher note:** grade the *dashboard interactivity* (does the filter work?) and the *view choices*
(right chart for each question), not pixel-perfect formatting.
